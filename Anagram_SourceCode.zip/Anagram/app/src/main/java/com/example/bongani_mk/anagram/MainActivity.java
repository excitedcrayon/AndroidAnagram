package com.example.bongani_mk.anagram;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView wordTv;
    private EditText wordEntered;
    private Button validateButton, newGameButton, exitButton;
    private String wordToFind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wordTv = findViewById(R.id.wordTv);
        wordEntered = findViewById(R.id.wordEntered);
        validateButton = findViewById(R.id.validate);
        newGameButton = findViewById(R.id.newGame);
        exitButton = findViewById(R.id.exit);
        validateButton.setOnClickListener(this);
        newGameButton.setOnClickListener(this);
        exitButton.setOnClickListener(this);

        newGame();
    }

    @Override
    public void onClick(View view) {
        if(view == validateButton){
            validate();
        }else if (view == newGameButton){
            newGame();
        }else if(view == exitButton){
            // close application
            finish();
            System.exit(0);
        }
    }

    public void validate(){
        String w = wordEntered.getText().toString();
        if(wordToFind.equals(w)){
            Toast.makeText(MainActivity.this, "Congratulations! You figured the word " + wordToFind,
                    Toast.LENGTH_LONG).show();
            newGame();
        }else{
            Toast.makeText(MainActivity.this,"Retry!",
                    Toast.LENGTH_LONG).show();
        }
    }
    public void newGame(){
        wordToFind = Anagram.randomWord();
        String wordShuffled = Anagram.shuffleWord(wordToFind);
        wordTv.setText(wordShuffled);
        wordEntered.setText("");
    }
}
